import tkinter as tk
from tkinter import messagebox

def bellman_ford(graph, V, source):
    distance = [float('inf')] * V
    distance[source] = 0

    for _ in range(V - 1):
        for u, v, w in graph:
            if distance[u] != float('inf') and distance[u] + w < distance[v]:
                distance[v] = distance[u] + w

    # Vérification de cycle négatif
    for u, v, w in graph:
        if distance[u] != float('inf') and distance[u] + w < distance[v]:
            return None  # Cycle de poids négatif détecté

    return distance

def Main():
    def valider_nb():
        try:
            nb = int(entree_sommets.get())
            if nb <= 1:
                raise ValueError
        except:
            messagebox.showerror("Erreur", "Veuillez entrer un nombre entier > 1.")
            return

        bouton_valider.config(state="disabled")
        entree_sommets.config(state="disabled")

        for i in range(5):
            ligne = tk.Entry(frame, width=50)
            ligne.pack(pady=2)
            lignes_aretes.append(ligne)

        label_source = tk.Label(frame, text="Source (index entier) :")
        label_source.pack()
        entree_source.pack()

        bouton_algo.pack(pady=10)

    def lancer_algo():
        try:
            V = int(entree_sommets.get())
            source = int(entree_source.get())
            if not (0 <= source < V):
                raise ValueError("Source hors limites")

            graph = []
            for ligne in lignes_aretes:
                texte = ligne.get()
                if texte.strip() == "":
                    continue
                u, v, w = map(int, texte.split(","))
                graph.append((u, v, w))

            resultats = bellman_ford(graph, V, source)
            if resultats is None:
                messagebox.showinfo("Résultat", "Un cycle de poids négatif a été détecté.")
            else:
                texte = "\n".join([f"Distance de {source} à {i} : {d}" for i, d in enumerate(resultats)])
                messagebox.showinfo("Distances minimales", texte)

        except Exception as e:
            messagebox.showerror("Erreur", f"Entrée invalide : {e}")

    # Interface
    fen = tk.Toplevel()
    fen.title("Bellman-Ford")

    lignes_aretes = []

    tk.Label(fen, text="Nombre de sommets dans le graphe :").pack()
    entree_sommets = tk.Entry(fen)
    entree_sommets.pack()

    bouton_valider = tk.Button(fen, text="Valider", command=valider_nb)
    bouton_valider.pack(pady=5)

    frame = tk.Frame(fen)
    frame.pack(pady=5)

    tk.Label(frame, text="Entrez les arêtes (u,v,poids) :").pack()

    entree_source = tk.Entry(frame)

    bouton_algo = tk.Button(fen, text="Lancer l'algorithme", command=lancer_algo)
