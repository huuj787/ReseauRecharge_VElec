import tkinter as tk
from tkinter import messagebox

def Main():
    # Variables locales
    nb_sommets = [0]
    graphe = [{}]

    def valider_nb():
        try:
            n = int(entree_nb.get())
            if n <= 0:
                raise ValueError
            nb_sommets[0] = n
            graphe[0] = {i: [] for i in range(n)}
            entree_nb.config(state="disabled")
            bouton_valider.config(state="disabled")
            afficher_zone_saisie()
        except ValueError:
            messagebox.showerror("Erreur", "Veuillez entrer un nombre valide.")

    def ajouter_arete():
        try:
            u = int(entree_u.get())
            v = int(entree_v.get())
            w = int(entree_w.get())
            if u < 0 or v < 0 or u >= nb_sommets[0] or v >= nb_sommets[0]:
                raise ValueError
            graphe[0][u].append((v, w))
            messagebox.showinfo("Succès", f"Ajouté : {u} → {v} (distance {w})")
            entree_u.delete(0, tk.END)
            entree_v.delete(0, tk.END)
            entree_w.delete(0, tk.END)
        except ValueError:
            messagebox.showerror("Erreur", "Veuillez entrer des entiers valides.")

    def dijkstra_algo(graphe_dict, depart, arrivee):
        import heapq
        distances = {v: float('inf') for v in range(nb_sommets[0])}
        distances[depart] = 0
        parent = {v: None for v in range(nb_sommets[0])}
        queue = [(0, depart)]

        while queue:
            dist_u, u = heapq.heappop(queue)
            for v, poids in graphe_dict[u]:
                if distances[v] > dist_u + poids:
                    distances[v] = dist_u + poids
                    parent[v] = u
                    heapq.heappush(queue, (distances[v], v))

        chemin = []
        actuel = arrivee
        while actuel is not None:
            chemin.insert(0, actuel)
            actuel = parent[actuel]

        return distances[arrivee], chemin

    def lancer_algo():
        try:
            depart = int(entree_depart.get())
            arrivee = int(entree_arrivee.get())
            if depart < 0 or arrivee < 0 or depart >= nb_sommets[0] or arrivee >= nb_sommets[0]:
                raise ValueError
            distance, chemin = dijkstra_algo(graphe[0], depart, arrivee)
            if distance == float('inf'):
                messagebox.showinfo("Résultat", "Aucun chemin trouvé.")
            else:
                chemin_str = " → ".join(map(str, chemin))
                messagebox.showinfo("Résultat", f"Chemin : {chemin_str}\nDistance : {distance}")
        except ValueError:
            messagebox.showerror("Erreur", "Entrées non valides.")

    def afficher_zone_saisie():
        saisie_frame = tk.Frame(fenetre)
        saisie_frame.pack(pady=10)

        # Champs pour les arêtes
        tk.Label(saisie_frame, text="u:").grid(row=0, column=0)
        tk.Label(saisie_frame, text="v:").grid(row=1, column=0)
        tk.Label(saisie_frame, text="distance:").grid(row=2, column=0)

        nonlocal entree_u, entree_v, entree_w
        entree_u = tk.Entry(saisie_frame)
        entree_v = tk.Entry(saisie_frame)
        entree_w = tk.Entry(saisie_frame)

        entree_u.grid(row=0, column=1)
        entree_v.grid(row=1, column=1)
        entree_w.grid(row=2, column=1)

        tk.Button(saisie_frame, text="Ajouter arête", command=ajouter_arete).grid(row=3, columnspan=2, pady=5)

        # Départ et arrivée
        tk.Label(saisie_frame, text="Départ:").grid(row=4, column=0)
        tk.Label(saisie_frame, text="Arrivée:").grid(row=5, column=0)

        nonlocal entree_depart, entree_arrivee
        entree_depart = tk.Entry(saisie_frame)
        entree_arrivee = tk.Entry(saisie_frame)

        entree_depart.grid(row=4, column=1)
        entree_arrivee.grid(row=5, column=1)

        tk.Button(saisie_frame, text="Lancer Dijkstra", command=lancer_algo).grid(row=6, columnspan=2, pady=10)

    # ✅ Ouvre une *nouvelle* fenêtre SANS quitter l'accueil
    fenetre = tk.Toplevel()
    fenetre.title("Algorithme de Dijkstra")
    fenetre.geometry("400x500")

    # Interface de départ
    tk.Label(fenetre, text="Nombre de stations (sommets) :").pack(pady=10)
    entree_nb = tk.Entry(fenetre)
    entree_nb.pack()

    bouton_valider = tk.Button(fenetre, text="Valider", command=valider_nb)
    bouton_valider.pack(pady=5)

    # Déclarations de variables utilisées dans afficher_zone_saisie()
    entree_u = entree_v = entree_w = entree_depart = entree_arrivee = None
