import tkinter as tk
from tkinter import messagebox

def Main():
    def valider_nb():
        try:
            n = int(entree_nb_sommets.get())
        except ValueError:
            messagebox.showerror("Erreur", "Veuillez entrer un entier.")
            return

        bouton_valider.config(state="disabled")
        entree_nb_sommets.config(state="disabled")

        afficher_zone_matrice(n)

    def afficher_zone_matrice(n):
        nonlocal nb_sommets
        nb_sommets = n

        label_matrice = tk.Label(fenetre, text="Entrez la matrice des capacités :")
        label_matrice.pack()

        for i in range(n):
            ligne = tk.Entry(fenetre, width=40)
            ligne.pack()
            entrees_matrice.append(ligne)

        label_source = tk.Label(fenetre, text="Source (index entier)")
        label_source.pack()
        entrees_infos.append(label_source)

        entree_source = tk.Entry(fenetre, width=10)
        entree_source.pack()
        entrees_infos.append(entree_source)

        label_puit = tk.Label(fenetre, text="Puit (index entier)")
        label_puit.pack()
        entrees_infos.append(label_puit)

        entree_puit = tk.Entry(fenetre, width=10)
        entree_puit.pack()
        entrees_infos.append(entree_puit)

        bouton_lancer = tk.Button(fenetre, text="Lancer l'algorithme", command=lancer_algo)
        bouton_lancer.pack(pady=10)

        entrees_infos.append(entree_source)
        entrees_infos.append(entree_puit)

    def bfs(rGraph, s, t, parent):
        visited = [False] * len(rGraph)
        queue = []

        queue.append(s)
        visited[s] = True

        while queue:
            u = queue.pop(0)
            for v, val in enumerate(rGraph[u]):
                if not visited[v] and val > 0:
                    queue.append(v)
                    visited[v] = True
                    parent[v] = u

        return visited[t]

    def ford_fulkerson(graph, source, sink):
        rGraph = [row[:] for row in graph]
        parent = [-1] * len(graph)
        max_flow = 0

        while bfs(rGraph, source, sink, parent):
            path_flow = float('inf')
            s = sink
            while s != source:
                path_flow = min(path_flow, rGraph[parent[s]][s])
                s = parent[s]

            max_flow += path_flow
            v = sink
            while v != source:
                u = parent[v]
                rGraph[u][v] -= path_flow
                rGraph[v][u] += path_flow
                v = parent[v]

        return max_flow

    def lancer_algo():
        try:
            matrice = []
            for ligne in entrees_matrice:
                valeurs = list(map(int, ligne.get().split(",")))
                if len(valeurs) != nb_sommets:
                    raise ValueError("Chaque ligne doit avoir le bon nombre de colonnes.")
                matrice.append(valeurs)

            source = int(entrees_infos[-2].get())
            puit = int(entrees_infos[-1].get())
            if not (0 <= source < nb_sommets) or not (0 <= puit < nb_sommets):
                raise ValueError("Source et puit doivent être des indices valides.")

        except Exception as e:
            messagebox.showerror("Erreur", str(e))
            return

        resultat = ford_fulkerson(matrice, source, puit)
        messagebox.showinfo("Résultat", f"Flot maximal : {resultat}")

    # Initialisation de l'interface
    fenetre = tk.Tk()
    fenetre.title("Algorithme de Flots - Flot Maximal")
    fenetre.geometry("500x500")

    nb_sommets = 0
    entrees_matrice = []
    entrees_infos = []

    label_nb = tk.Label(fenetre, text="Nombre de sommets dans le graphe :")
    label_nb.pack()

    entree_nb_sommets = tk.Entry(fenetre)
    entree_nb_sommets.pack()

    bouton_valider = tk.Button(fenetre, text="Valider", command=valider_nb)
    bouton_valider.pack(pady=10)

    fenetre.mainloop()
