import tkinter as tk
from tkinter import messagebox

def Main():
    nb_stations = 0
    arretes = []

    def ajouter_arete():
        try:
            u = int(entree_u.get())
            v = int(entree_v.get())
            w = int(entree_w.get())
            if u < 0 or u >= nb_stations or v < 0 or v >= nb_stations:
                messagebox.showerror("Erreur", "Indices de stations hors limites.")
                return
            arretes.append((w, u, v))
            messagebox.showinfo("Ajouté", f"Connexion {u} — {v} (coût : {w}) ajoutée.")
            entree_u.delete(0, tk.END)
            entree_v.delete(0, tk.END)
            entree_w.delete(0, tk.END)
        except ValueError:
            messagebox.showerror("Erreur", "Entrez des entiers valides pour u, v et w.")

    def trouver(parent, i):
        if parent[i] != i:
            parent[i] = trouver(parent, parent[i])
        return parent[i]

    def union(parent, rank, x, y):
        xroot = trouver(parent, x)
        yroot = trouver(parent, y)
        if rank[xroot] < rank[yroot]:
            parent[xroot] = yroot
        elif rank[xroot] > rank[yroot]:
            parent[yroot] = xroot
        else:
            parent[yroot] = xroot
            rank[xroot] += 1

    def kruskal():
        parent = [i for i in range(nb_stations)]
        rank = [0] * nb_stations
        arretes_choisies = []
        arretes.sort()

        for w, u, v in arretes:
            if trouver(parent, u) != trouver(parent, v):
                arretes_choisies.append((u, v, w))
                union(parent, rank, u, v)

        if len(arretes_choisies) < nb_stations - 1:
            messagebox.showwarning("Résultat", "Le réseau ne peut pas être connecté complètement.")
        else:
            total = sum(w for _, _, w in arretes_choisies)
            texte = "\n".join([f"{u} — {v} : {w}" for u, v, w in arretes_choisies])
            messagebox.showinfo("Arbre couvrant minimum", f"Connexions :\n{texte}\n\nCoût total : {total}")

    fen = tk.Toplevel()
    fen.title("Kruskal – Connexion optimale des stations")
    fen.geometry("500x500")

    tk.Label(fen, text="Nombre de stations :").pack()
    entree_nb = tk.Entry(fen)
    entree_nb.pack()

    def valider_nb():
        nonlocal nb_stations
        try:
            val = int(entree_nb.get())
            if val <= 0:
                raise ValueError
            nb_stations = val
            entree_nb.config(state="disabled")
            btn_valider.config(state="disabled")
            afficher_zone_saisie()
        except ValueError:
            messagebox.showerror("Erreur", "Veuillez entrer un nombre entier positif.")

    btn_valider = tk.Button(fen, text="Valider", command=valider_nb)
    btn_valider.pack(pady=10)

    def afficher_zone_saisie():
        tk.Label(fen, text="Ajouter une connexion (u, v, poids)").pack()

        global entree_u, entree_v, entree_w
        entree_u = tk.Entry(fen)
        entree_u.pack()
        entree_v = tk.Entry(fen)
        entree_v.pack()
        entree_w = tk.Entry(fen)
        entree_w.pack()

        btn_ajout = tk.Button(fen, text="Ajouter l’arête", command=ajouter_arete)
        btn_ajout.pack(pady=5)

        btn_exec = tk.Button(fen, text="Exécuter Kruskal", command=kruskal)
        btn_exec.pack(pady=10)
