import tkinter as tk
from tkinter import messagebox
import numpy as np

def Main():
    def valider_dimensions():
        try:
            nonlocal nb_sources, nb_destinations
            nb_sources = int(entree_sources.get())
            nb_destinations = int(entree_destinations.get())
            if nb_sources <= 0 or nb_destinations <= 0:
                raise ValueError
        except ValueError:
            messagebox.showerror("Erreur", "Veuillez entrer des entiers positifs pour les dimensions.")
            return

        entree_sources.config(state='disabled')
        entree_destinations.config(state='disabled')
        bouton_valider.config(state='disabled')
        afficher_champs_tableaux()

    def afficher_champs_tableaux():
        tk.Label(fenetre, text="Entrez les coûts (séparés par des virgules, ligne par ligne) :").pack()
        for _ in range(nb_sources):
            e = tk.Entry(fenetre)
            e.pack()
            entrees_couts.append(e)

        tk.Label(fenetre, text="Offres :").pack()
        for _ in range(nb_sources):
            e = tk.Entry(fenetre)
            e.pack()
            entrees_offres.append(e)

        tk.Label(fenetre, text="Demandes :").pack()
        for _ in range(nb_destinations):
            e = tk.Entry(fenetre)
            e.pack()
            entrees_demandes.append(e)

        tk.Button(fenetre, text="Lancer l'algorithme", command=lancer_algo).pack(pady=10)

    def moindre_cout(couts, offre, demande):
        n, m = len(offre), len(demande)
        allocation = np.zeros((n, m), dtype=int)
        offre = offre.copy()
        demande = demande.copy()

        while True:
            min_val = float('inf')
            pos = (-1, -1)
            for i in range(n):
                for j in range(m):
                    if offre[i] > 0 and demande[j] > 0 and couts[i][j] < min_val:
                        min_val = couts[i][j]
                        pos = (i, j)

            if pos == (-1, -1):
                break

            i, j = pos
            quantite = min(offre[i], demande[j])
            allocation[i][j] = quantite
            offre[i] -= quantite
            demande[j] -= quantite

        return allocation

    def lancer_algo():
        try:
            couts = []
            for e in entrees_couts:
                ligne = list(map(int, e.get().split(',')))
                if len(ligne) != nb_destinations:
                    raise ValueError("Chaque ligne de coûts doit contenir exactement {} valeurs.".format(nb_destinations))
                couts.append(ligne)

            offres = list(map(int, [e.get() for e in entrees_offres]))
            demandes = list(map(int, [e.get() for e in entrees_demandes]))

            if sum(offres) != sum(demandes):
                messagebox.showerror("Erreur", "La somme des offres doit être égale à la somme des demandes.")
                return

            allocation = moindre_cout(couts, offres, demandes)

            resultats = "Résultat d'allocation (quantités par case):\n"
            for i in range(nb_sources):
                resultats += f"Source {i} : {allocation[i].tolist()}\n"

            cout_total = sum(allocation[i][j] * couts[i][j] for i in range(nb_sources) for j in range(nb_destinations))
            resultats += f"\nCoût total : {cout_total}"

            messagebox.showinfo("Résultat", resultats)

        except Exception as e:
            messagebox.showerror("Erreur", f"Une erreur s'est produite : {e}")

    fenetre = tk.Toplevel()
    fenetre.title("Algorithme du Moindre Coût")
    fenetre.geometry("500x700")

    nb_sources = 0
    nb_destinations = 0
    entrees_couts = []
    entrees_offres = []
    entrees_demandes = []

    tk.Label(fenetre, text="Nombre de sources :").pack()
    entree_sources = tk.Entry(fenetre)
    entree_sources.pack()

    tk.Label(fenetre, text="Nombre de destinations :").pack()
    entree_destinations = tk.Entry(fenetre)
    entree_destinations.pack()

    bouton_valider = tk.Button(fenetre, text="Valider", command=valider_dimensions)
    bouton_valider.pack(pady=10)
