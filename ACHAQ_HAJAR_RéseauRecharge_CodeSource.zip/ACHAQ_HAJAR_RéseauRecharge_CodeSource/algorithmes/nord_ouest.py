import tkinter as tk
from tkinter import messagebox

def Main():
    matrice = []
    offre = []
    demande = []
    nb_sources = 0
    nb_destinations = 0

    def valider_dimensions():
        nonlocal nb_sources, nb_destinations
        try:
            nb_sources = int(entree_sources.get())
            nb_destinations = int(entree_destinations.get())
            if nb_sources <= 0 or nb_destinations <= 0:
                raise ValueError
            entree_sources.config(state='disabled')
            entree_destinations.config(state='disabled')
            btn_valider.config(state='disabled')
            afficher_saisie_donnees()
        except:
            messagebox.showerror("Erreur", "Entrez des entiers valides (> 0).")

    def afficher_saisie_donnees():
        for i in range(nb_sources):
            tk.Label(fen, text=f"Offre source {i+1}").pack()
            e = tk.Entry(fen)
            e.pack()
            offre_entries.append(e)

        for j in range(nb_destinations):
            tk.Label(fen, text=f"Demande station {j+1}").pack()
            e = tk.Entry(fen)
            e.pack()
            demande_entries.append(e)

        tk.Label(fen, text="Coûts de transport (lignes=sources, colonnes=stations)").pack()
        for i in range(nb_sources):
            ligne = []
            for j in range(nb_destinations):
                e = tk.Entry(fen, width=5)
                e.pack()
                ligne.append(e)
            couts_entries.append(ligne)

        btn_calcule.pack(pady=10)

    def lancer_algo():
        try:
            nonlocal offre, demande, matrice
            offre = [int(e.get()) for e in offre_entries]
            demande = [int(e.get()) for e in demande_entries]
            matrice = [[int(e.get()) for e in ligne] for ligne in couts_entries]

            if sum(offre) != sum(demande):
                messagebox.showerror("Erreur", "L’offre totale doit être égale à la demande totale.")
                return

            allocation = [[0] * nb_destinations for _ in range(nb_sources)]
            i = j = 0
            reste_offre = offre.copy()
            reste_demande = demande.copy()

            while i < nb_sources and j < nb_destinations:
                val = min(reste_offre[i], reste_demande[j])
                allocation[i][j] = val
                reste_offre[i] -= val
                reste_demande[j] -= val
                if reste_offre[i] == 0:
                    i += 1
                elif reste_demande[j] == 0:
                    j += 1

            resultat = "Allocation :\n"
            for i in range(nb_sources):
                for j in range(nb_destinations):
                    resultat += f"{allocation[i][j]}  "
                resultat += "\n"
            messagebox.showinfo("Résultat - Méthode du Nord-Ouest", resultat)
        except Exception as e:
            messagebox.showerror("Erreur", f"Vérifiez les données : {e}")

    fen = tk.Toplevel()
    fen.title("Méthode du Nord-Ouest – Réseau Recharge VE")
    fen.geometry("500x700")

    tk.Label(fen, text="Nombre de sources (usines) :").pack()
    entree_sources = tk.Entry(fen)
    entree_sources.pack()

    tk.Label(fen, text="Nombre de destinations (stations) :").pack()
    entree_destinations = tk.Entry(fen)
    entree_destinations.pack()

    btn_valider = tk.Button(fen, text="Valider", command=valider_dimensions)
    btn_valider.pack(pady=10)

    offre_entries = []
    demande_entries = []
    couts_entries = []

    btn_calcule = tk.Button(fen, text="Lancer l'algorithme", command=lancer_algo)
