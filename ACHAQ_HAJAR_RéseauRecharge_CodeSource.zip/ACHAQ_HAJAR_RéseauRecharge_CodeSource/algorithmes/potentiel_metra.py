import tkinter as tk
from tkinter import messagebox

def calcul_potentiel_metra(taches):
    n = len(taches)
    debut = {}
    fin = {}
    
    # Initialiser début à 0 pour tous
    for tache in taches:
        debut[tache['id']] = 0

    # Ordonnancement au plus tôt
    for tache in taches:
        d = tache['duree']
        for succ in tache['successeurs']:
            debut[succ] = max(debut.get(succ, 0), debut[tache['id']] + d)

    # Calcul de la durée totale
    duree_totale = max(debut[t['id']] + t['duree'] for t in taches)

    # Initialiser les dates au plus tard
    for tache in taches:
        fin[tache['id']] = duree_totale

    # Ordonnancement au plus tard
    for tache in reversed(taches):
        d = tache['duree']
        for succ in tache['successeurs']:
            fin[tache['id']] = min(fin[tache['id']], fin[succ] - d)

    # Affichage
    resultats = []
    for t in taches:
        marge = fin[t['id']] - debut[t['id']]
        critique = "Oui" if marge == 0 else "Non"
        resultats.append(f"Tâche {t['id']} - Début: {debut[t['id']]} | Fin: {fin[t['id']]} | Marge: {marge} | Critique: {critique}")

    return resultats, duree_totale


def Main():
    fenetre = tk.Toplevel()
    fenetre.title("Potentiel de Métra (PERT)")
    fenetre.geometry("600x600")
    fenetre.configure(bg="white")

    taches = []

    def ajouter_tache():
        try:
            id_tache = entree_id.get()
            duree = int(entree_duree.get())
            successeurs = [s.strip() for s in entree_succ.get().split(",") if s.strip()]
            taches.append({'id': id_tache, 'duree': duree, 'successeurs': successeurs})
            liste_taches.insert(tk.END, f"Tâche {id_tache} - Durée: {duree} - Successeurs: {successeurs}")
            entree_id.delete(0, tk.END)
            entree_duree.delete(0, tk.END)
            entree_succ.delete(0, tk.END)
        except ValueError:
            messagebox.showerror("Erreur", "Veuillez entrer une durée valide (entier).")

    def lancer_calcul():
        if not taches:
            messagebox.showwarning("Attention", "Aucune tâche ajoutée.")
            return
        resultats, total = calcul_potentiel_metra(taches)
        zone_resultat.delete("1.0", tk.END)
        zone_resultat.insert(tk.END, f"Durée totale du projet : {total}\n\n")
        for ligne in resultats:
            zone_resultat.insert(tk.END, ligne + "\n")

    # Entrées
    tk.Label(fenetre, text="ID Tâche:", bg="white").pack()
    entree_id = tk.Entry(fenetre)
    entree_id.pack()

    tk.Label(fenetre, text="Durée:", bg="white").pack()
    entree_duree = tk.Entry(fenetre)
    entree_duree.pack()

    tk.Label(fenetre, text="Successeurs (séparés par des virgules):", bg="white").pack()
    entree_succ = tk.Entry(fenetre)
    entree_succ.pack()

    tk.Button(fenetre, text="Ajouter la tâche", command=ajouter_tache, bg="#B3FFF0").pack(pady=10)

    liste_taches = tk.Listbox(fenetre, width=80, height=6)
    liste_taches.pack(pady=5)

    tk.Button(fenetre, text="Calculer le potentiel de Métra", command=lancer_calcul, bg="#7DCEA0").pack(pady=10)

    zone_resultat = tk.Text(fenetre, height=15, width=70, bg="#F8F9F9")
    zone_resultat.pack(pady=10)

    fenetre.mainloop()
