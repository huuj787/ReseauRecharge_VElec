import tkinter as tk
from tkinter import messagebox
import numpy as np

def Main():
    root = tk.Tk()
    root.title("Algorithme du Simplexe")
    root.geometry("700x600")

    label_intro = tk.Label(root, text="Entrez le nombre de variables et de contraintes", font=("Helvetica", 14))
    label_intro.pack(pady=10)

    frame_input = tk.Frame(root)
    frame_input.pack(pady=5)

    tk.Label(frame_input, text="Nombre de variables :").grid(row=0, column=0, padx=5, pady=5)
    entry_vars = tk.Entry(frame_input)
    entry_vars.grid(row=0, column=1)

    tk.Label(frame_input, text="Nombre de contraintes :").grid(row=1, column=0, padx=5, pady=5)
    entry_constraints = tk.Entry(frame_input)
    entry_constraints.grid(row=1, column=1)

    def valider():
        try:
            n = int(entry_vars.get())
            m = int(entry_constraints.get())
        except ValueError:
            messagebox.showerror("Erreur", "Veuillez entrer des entiers valides.")
            return

        frame_input.destroy()
        label_intro.destroy()
        afficher_zone_donnees(n, m)

    tk.Button(root, text="Valider", command=valider).pack(pady=10)

    def afficher_zone_donnees(n, m):
        label_obj = tk.Label(root, text="Fonction Objectif (Maximiser)", font=("Helvetica", 12))
        label_obj.pack(pady=5)

        frame_obj = tk.Frame(root)
        frame_obj.pack()

        coef_obj = []
        for i in range(n):
            e = tk.Entry(frame_obj, width=5)
            e.grid(row=0, column=i)
            coef_obj.append(e)

        label_const = tk.Label(root, text="Contraintes (<=) :", font=("Helvetica", 12))
        label_const.pack(pady=5)

        frame_const = tk.Frame(root)
        frame_const.pack()

        entries_constraints = []
        for i in range(m):
            row_entries = []
            for j in range(n):
                e = tk.Entry(frame_const, width=5)
                e.grid(row=i, column=j)
                row_entries.append(e)
            label_le = tk.Label(frame_const, text="<=")
            label_le.grid(row=i, column=n)
            e_b = tk.Entry(frame_const, width=5)
            e_b.grid(row=i, column=n+1)
            row_entries.append(e_b)
            entries_constraints.append(row_entries)

        def resolution():
            try:
                c = np.array([float(e.get()) for e in coef_obj])
                A = []
                b = []
                for row in entries_constraints:
                    A.append([float(e.get()) for e in row[:-1]])
                    b.append(float(row[-1].get()))
                A = np.array(A)
                b = np.array(b)
                res = simplexe(c, A, b)
                messagebox.showinfo("Résultat", f"Valeur optimale : {res[0]}\nSolution : {res[1]}")
            except ValueError:
                messagebox.showerror("Erreur", "Veuillez remplir correctement tous les champs.")

        tk.Button(root, text="Résoudre", command=resolution).pack(pady=10)

    def simplexe(c, A, b):
        from scipy.optimize import linprog
        res = linprog(-c, A_ub=A, b_ub=b, method='simplex')
        if res.success:
            return (-res.fun, res.x)
        else:
            return ("Problème sans solution", [])

    root.mainloop()
