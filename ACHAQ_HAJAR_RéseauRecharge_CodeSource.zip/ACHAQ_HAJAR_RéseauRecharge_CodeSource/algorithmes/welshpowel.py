import tkinter as tk
from tkinter import messagebox

def Main():
    def valider_nb():
        try:
            nb = int(entree_nb.get())
            if nb <= 0:
                raise ValueError
            entree_nb.config(state="disabled")
            btn_valider.config(state="disabled")
            afficher_zone_ajout(nb)
        except:
            messagebox.showerror("Erreur", "Entrez un nombre valide de sommets.")

    def afficher_zone_ajout(nb):
        for i in range(nb):
            for j in range(i + 1, nb):
                lbl = tk.Label(fenetre, text=f"Arête entre {i} et {j} ? (1=oui, 0=non)")
                lbl.pack()
                e = tk.Entry(fenetre, width=5)
                e.pack()
                entrees_aretes.append(((i, j), e))
        bouton_lancer.pack(pady=10)

    def lancer_algo():
        try:
            graphe = {}
            for (i, j), e in entrees_aretes:
                val = int(e.get())
                if val == 1:
                    graphe.setdefault(i, []).append(j)
                    graphe.setdefault(j, []).append(i)

            degres = sorted(graphe.items(), key=lambda x: len(x[1]), reverse=True)
            couleur = {}
            c = 0
            for sommet, _ in degres:
                if sommet not in couleur:
                    couleur[sommet] = c
                    for autre, _ in degres:
                        if autre not in couleur:
                            if all(couleur.get(voisin) != c for voisin in graphe.get(autre, [])):
                                couleur[autre] = c
                    c += 1

            result = "\n".join([f"Sommet {k} → Couleur {v}" for k, v in couleur.items()])
            messagebox.showinfo("Résultat Welsh-Powell", result)
        except Exception as e:
            messagebox.showerror("Erreur", f"Vérifiez les données : {e}")

    fenetre = tk.Toplevel()
    fenetre.title("Welsh-Powell – Réseau Recharge VE")
    fenetre.geometry("500x600")

    tk.Label(fenetre, text="Nombre de sommets (stations)").pack()
    entree_nb = tk.Entry(fenetre)
    entree_nb.pack()

    btn_valider = tk.Button(fenetre, text="Valider", command=valider_nb)
    btn_valider.pack(pady=10)

    entrees_aretes = []

    bouton_lancer = tk.Button(fenetre, text="Lancer l'algorithme", command=lancer_algo)
