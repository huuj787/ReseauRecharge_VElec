import tkinter as tk
from algorithmes.simplexe import Main as SimplexeMain
from algorithmes.dijkstra import Main as DijkstraMain
from algorithmes.welshpowel import Main as WelshPowelMain
from algorithmes.kruskal import Main as KruskalMain
from algorithmes.flots import Main as FlotsMain
from algorithmes.nord_ouest import Main as NordOuestMain
from algorithmes.moindre_cout import Main as MoindreCoutMain
from algorithmes.bellman_ford import Main as BellmanFordMain
from algorithmes.potentiel_metra import Main as PotentielMetraMain

def creer_interface():
    fenetre = tk.Tk()
    fenetre.title("Planification d’un Réseau de Recharge pour Véhicules Électriques")
    fenetre.geometry("700x500")
    fenetre.configure(bg="#f0f0f0")

    titre = tk.Label(fenetre, text="Choisissez un algorithme", font=("Helvetica", 18, "bold"), bg="#f0f0f0")
    titre.pack(pady=20)

    frame_boutons = tk.Frame(fenetre, bg="#f0f0f0")
    frame_boutons.pack()

    algorithmes = [
        ("Simplexe", "#FF9999", SimplexeMain),
        ("Dijkstra", "#99CCFF", DijkstraMain),
        ("Welsh-Powell", "#FFFF99", WelshPowelMain),
        ("Kruskal", "#CCFFCC", KruskalMain),
        ("Flots", "#FFCC99", FlotsMain),
        ("Nord-Ouest", "#D9B3FF", NordOuestMain),
        ("Moindre Coût", "#FFB3E6", MoindreCoutMain),
        ("Bellman-Ford", "#CCE5FF", BellmanFordMain),
        ("Potentiel Métra", "#B3FFF0", PotentielMetraMain)
    ]

    for nom, couleur, fonction in algorithmes:
        bouton = tk.Button(
            frame_boutons,
            text=nom,
            command=fonction,
            width=40,
            height=2,
            bg=couleur,
            fg="black",
            font=("Arial", 10, "bold")
        )
        bouton.pack(pady=5)

    fenetre.mainloop()

if __name__ == "__main__":
    creer_interface()
