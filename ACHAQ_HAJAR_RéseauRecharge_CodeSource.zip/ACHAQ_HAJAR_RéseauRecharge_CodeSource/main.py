from interface import creer_interface

if __name__ == "__main__":
    creer_interface()
